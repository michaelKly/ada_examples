--  Grade_Report (STARTER CODE)
--
--  Student Grade Report Generator -- Task A
--
--  Fill in the TODOs below to complete the assignment. The Student
--  record type, array, and sample data are provided for you. You need
--  to implement the letter grade logic, the main report loop, and the
--  summary statistics (average, highest, lowest).

with Ada.Text_IO; use Ada.Text_IO;
with Ada.Float_Text_IO; use Ada.Float_Text_IO;

procedure Grade_Report is

   type Student is record
      Name  : String (1 .. 15);
      Score : Integer;  --  0 .. 100
   end record;

   Num_Students : constant := 6;
   type Student_Array is array (1 .. Num_Students) of Student;

   --  Helper: pads a short string out to a fixed 15-character length so
   --  it can be stored in the Student.Name field. You don't need to
   --  modify this -- just use Pad ("SomeName") when building the array
   --  below.
   function Pad (S : String) return String is
      Result : String (1 .. 15) := (others => ' ');
   begin
      Result (1 .. S'Length) := S;
      return Result;
   end Pad;

   --  TODO: Feel free to change these names/scores, or add more students
   --  (just update Num_Students above to match).
   Students : Student_Array :=
     ((Pad ("Alice"),   92),
      (Pad ("Ben"),      74),
      (Pad ("Carla"),    58),
      (Pad ("Diego"),    85),
      (Pad ("Ella"),     67),
      (Pad ("Frank"),   100));

   --  TODO: Implement this function.
   --  Given a numeric score, return the correct letter grade using a
   --  case statement:
   --     90-100 -> 'A'   80-89 -> 'B'   70-79 -> 'C'
   --     60-69  -> 'D'   0-59  -> 'F'
   function Letter_Grade (Score : Integer) return Character is
   begin
      raise Program_Error with "Letter_Grade not implemented yet";
      return '?';  --  unreachable; keeps the compiler happy until you
                   --  replace this function with your case statement
   end Letter_Grade;

   --  Variables you'll need for computing the summary stats.
   --  TODO: You may need to initialize Highest/Lowest differently
   --  depending on how you structure your loop below.
   Total   : Integer := 0;
   Average : Float;
   Highest : Student := Students (1);
   Lowest  : Student := Students (1);

begin
   Put_Line ("Student Grade Report");
   New_Line;

   --  TODO: Loop over Students and, for each one:
   --    1. Print the student's name, score, and letter grade
   --       (call Letter_Grade once you've implemented it above).
   --    2. Add the student's score to Total.
   --    3. Update Highest / Lowest if this student beats the current
   --       record holder.
   for S of Students loop
      null;  --  remove this once you fill in the loop body
   end loop;

   --  TODO: Compute Average from Total and Num_Students.
   --  Careful: integer division truncates! You'll need to convert to
   --  Float before dividing.
   Average := 0.0;

   New_Line;
   Put ("Class Average: ");
   Put (Average, Fore => 3, Aft => 2, Exp => 0);
   New_Line;

   --  TODO: Print the highest and lowest scoring students, similar to
   --  the format used in the per-student loop above.

end Grade_Report;
